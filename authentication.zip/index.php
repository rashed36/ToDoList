
<!DOCTYPE html>
<html>
<body>

<script>

  location.replace("http://127.0.0.1:8000/login")
</script>

</body>
</html> 
